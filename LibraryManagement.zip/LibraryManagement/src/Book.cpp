#include "Book.h"
#include <iostream>

Book::Book(int id, const std::string &title, const std::string &author,
           const std::string &category, double cost, const std::string &procurementDate)
    : id(id), title(title), author(author), category(category),
      isIssued(false), cost(cost), procurementDate(procurementDate) {}

int Book::getId() const { return id; }
std::string Book::getTitle() const { return title; }
std::string Book::getAuthor() const { return author; }
std::string Book::getCategory() const { return category; }
bool Book::getIsIssued() const { return isIssued; }
double Book::getCost() const { return cost; }
std::string Book::getProcurementDate() const { return procurementDate; }

void Book::setIssued(bool issued) {
    isIssued = issued;
}

void Book::display() const {
    std::cout << "ID: " << id 
              << " | Title: " << title 
              << " | Author: " << author 
              << " | Category: " << category
              << " | Cost: $" << cost 
              << " | Procurement Date: " << procurementDate 
              << " | Status: " << (isIssued ? "Issued" : "Available") 
              << std::endl;
}
