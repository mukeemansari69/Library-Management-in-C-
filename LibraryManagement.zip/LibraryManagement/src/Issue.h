#ifndef ISSUE_H
#define ISSUE_H

#include <string>

class Issue {
private:
    int issueId;
    int bookId;
    int memberId;
    int issueDate; // using integer to simulate date (e.g., day count)
    int dueDate;
    int returnDate; // 0 if not returned
    double fine;
public:
    Issue(int issueId, int bookId, int memberId, int issueDate, int dueDate);

    int getIssueId() const;
    int getBookId() const;
    int getMemberId() const;
    int getIssueDate() const;
    int getDueDate() const;
    int getReturnDate() const;
    double getFine() const;

    void setReturnDate(int returnDate);
    void calculateFine(int currentDate);
    void display() const;
};

#endif // ISSUE_H
