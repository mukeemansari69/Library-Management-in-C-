#ifndef LIBRARY_H
#define LIBRARY_H

#include <vector>
#include "Book.h"
#include "Member.h"
#include "Issue.h"

class Library {
private:
    std::vector<Book> books;
    std::vector<Member> members;
    std::vector<Issue> issues;
    int nextBookId;
    int nextMemberId;
    int nextIssueId;
public:
    Library();

    // Book functions
    void addBook(const std::string &title, const std::string &author,
                 const std::string &category, double cost, const std::string &procurementDate);
    void updateBook(int bookId, const std::string &title, const std::string &author,
                    const std::string &category, double cost, const std::string &procurementDate);
    void displayBooks() const;
    Book* findBook(int bookId);

    // Member functions
    void addMember(const std::string &name, const std::string &membershipType);
    void updateMember(int memberId, const std::string &name, const std::string &membershipType);
    void displayMembers() const;
    Member* findMember(int memberId);

    // Issue functions
    void issueBook(int bookId, int memberId, int issueDate, int dueDate);
    void returnBook(int issueId, int returnDate);
    void displayIssues() const;
    void displayOverdueIssues(int currentDate) const;
};

#endif // LIBRARY_H
