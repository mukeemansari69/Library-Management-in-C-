#include <iostream>
#include "Library.h"

using namespace std;

void adminMenu(Library &lib) {
    int choice;
    do {
        cout << "\n--- Admin Menu ---\n";
        cout << "1. Add Book\n";
        cout << "2. Update Book\n";
        cout << "3. Display Books\n";
        cout << "4. Add Member\n";
        cout << "5. Update Member\n";
        cout << "6. Display Members\n";
        cout << "7. Display Issued Books\n";
        cout << "8. Display Overdue Issues\n";
        cout << "9. Logout\n";
        cout << "Enter choice: ";
        cin >> choice;
        if (choice == 1) {
            string title, author, category, procurementDate;
            double cost;
            cout << "Enter title: "; 
            cin.ignore();
            getline(cin, title);
            cout << "Enter author: "; 
            getline(cin, author);
            cout << "Enter category: "; 
            getline(cin, category);
            cout << "Enter cost: "; 
            cin >> cost;
            cout << "Enter procurement date (e.g., YYYY-MM-DD): "; 
            cin >> procurementDate;
            lib.addBook(title, author, category, cost, procurementDate);
        } else if (choice == 2) {
            int bookId;
            string title, author, category, procurementDate;
            double cost;
            cout << "Enter book ID to update: "; 
            cin >> bookId;
            cout << "Enter new title: "; 
            cin.ignore();
            getline(cin, title);
            cout << "Enter new author: "; 
            getline(cin, author);
            cout << "Enter new category: "; 
            getline(cin, category);
            cout << "Enter new cost: "; 
            cin >> cost;
            cout << "Enter new procurement date (e.g., YYYY-MM-DD): "; 
            cin >> procurementDate;
            lib.updateBook(bookId, title, author, category, cost, procurementDate);
        } else if (choice == 3) {
            lib.displayBooks();
        } else if (choice == 4) {
            string name, membershipType;
            cout << "Enter member name: "; 
            cin.ignore();
            getline(cin, name);
            cout << "Enter membership type: "; 
            getline(cin, membershipType);
            lib.addMember(name, membershipType);
        } else if (choice == 5) {
            int memberId;
            string name, membershipType;
            cout << "Enter member ID to update: "; 
            cin >> memberId;
            cout << "Enter new member name: "; 
            cin.ignore();
            getline(cin, name);
            cout << "Enter new membership type: "; 
            getline(cin, membershipType);
            lib.updateMember(memberId, name, membershipType);
        } else if (choice == 6) {
            lib.displayMembers();
        } else if (choice == 7) {
            lib.displayIssues();
        } else if (choice == 8) {
            int currentDate;
            cout << "Enter current date (as integer, e.g., day count): ";
            cin >> currentDate;
            lib.displayOverdueIssues(currentDate);
        } else if (choice == 9) {
            cout << "Logging out..." << endl;
        } else {
            cout << "Invalid choice." << endl;
        }
    } while (choice != 9);
}

void userMenu(Library &lib) {
    int choice;
    do {
        cout << "\n--- User Menu ---\n";
        cout << "1. Search Book (by ID)\n";
        cout << "2. Issue Book\n";
        cout << "3. Return Book\n";
        cout << "4. Display Books\n";
        cout << "5. Logout\n";
        cout << "Enter choice: ";
        cin >> choice;
        if (choice == 1) {
            int bookId;
            cout << "Enter book ID to search: "; 
            cin >> bookId;
            Book* book = lib.findBook(bookId);
            if (book) {
                book->display();
            } else {
                cout << "Book not found." << endl;
            }
        } else if (choice == 2) {
            int bookId, memberId, issueDate, dueDate;
            cout << "Enter book ID to issue: "; 
            cin >> bookId;
            cout << "Enter your member ID: "; 
            cin >> memberId;
            cout << "Enter issue date (as integer): "; 
            cin >> issueDate;
            cout << "Enter due date (as integer): "; 
            cin >> dueDate;
            lib.issueBook(bookId, memberId, issueDate, dueDate);
        } else if (choice == 3) {
            int issueId, returnDate;
            cout << "Enter issue ID for returning the book: "; 
            cin >> issueId;
            cout << "Enter return date (as integer): "; 
            cin >> returnDate;
            lib.returnBook(issueId, returnDate);
        } else if (choice == 4) {
            lib.displayBooks();
        } else if (choice == 5) {
            cout << "Logging out..." << endl;
        } else {
            cout << "Invalid choice." << endl;
        }
    } while (choice != 5);
}

int main() {
    Library lib;
    int role;
    cout << "Welcome to the Library Management System\n";
    cout << "Select role: 1. Admin  2. User\n";
    cout << "Enter choice: ";
    cin >> role;
    if (role == 1) {
        string username, password;
        cout << "Enter Admin username: "; 
        cin >> username;
        cout << "Enter Admin password: "; 
        cin >> password;
        if (username == "adm" && password == "admin") {
            adminMenu(lib);
        } else {
            cout << "Invalid admin credentials." << endl;
        }
    } else if (role == 2) {
        string username, password;
        cout << "Enter User username: "; 
        cin >> username;
        cout << "Enter User password: "; 
        cin >> password;
        if (username == "user" && password == "user") {
            userMenu(lib);
        } else {
            cout << "Invalid user credentials." << endl;
        }
    } else {
        cout << "Invalid role selected." << endl;
    }
    cout << "Thank you for using the Library Management System.\n";
    return 0;
}
