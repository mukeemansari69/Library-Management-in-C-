#ifndef BOOK_H
#define BOOK_H

#include <string>

class Book {
private:
    int id;
    std::string title;
    std::string author;
    std::string category;
    bool isIssued;
    double cost;
    std::string procurementDate; // using string for simplicity
public:
    Book(int id, const std::string &title, const std::string &author,
         const std::string &category, double cost, const std::string &procurementDate);

    int getId() const;
    std::string getTitle() const;
    std::string getAuthor() const;
    std::string getCategory() const;
    bool getIsIssued() const;
    double getCost() const;
    std::string getProcurementDate() const;

    void setIssued(bool issued);
    void display() const;
};

#endif // BOOK_H
