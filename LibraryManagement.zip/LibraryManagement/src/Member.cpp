#include "Member.h"
#include <iostream>

Member::Member(int id, const std::string &name, const std::string &membershipType)
    : id(id), name(name), membershipType(membershipType) {}

int Member::getId() const { return id; }
std::string Member::getName() const { return name; }
std::string Member::getMembershipType() const { return membershipType; }

void Member::display() const {
    std::cout << "Member ID: " << id 
              << " | Name: " << name 
              << " | Membership Type: " << membershipType 
              << std::endl;
}
