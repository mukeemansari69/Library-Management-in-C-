#include "Issue.h"
#include <iostream>

Issue::Issue(int issueId, int bookId, int memberId, int issueDate, int dueDate)
    : issueId(issueId), bookId(bookId), memberId(memberId),
      issueDate(issueDate), dueDate(dueDate), returnDate(0), fine(0.0) {}

int Issue::getIssueId() const { return issueId; }
int Issue::getBookId() const { return bookId; }
int Issue::getMemberId() const { return memberId; }
int Issue::getIssueDate() const { return issueDate; }
int Issue::getDueDate() const { return dueDate; }
int Issue::getReturnDate() const { return returnDate; }
double Issue::getFine() const { return fine; }

void Issue::setReturnDate(int returnDate) {
    this->returnDate = returnDate;
}

void Issue::calculateFine(int currentDate) {
    if (currentDate > dueDate) {
        fine = (currentDate - dueDate) * 1.0; // $1 per day fine
    } else {
        fine = 0.0;
    }
}

void Issue::display() const {
    std::cout << "Issue ID: " << issueId 
              << " | Book ID: " << bookId 
              << " | Member ID: " << memberId 
              << " | Issue Date: " << issueDate 
              << " | Due Date: " << dueDate 
              << " | Return Date: " << (returnDate ? std::to_string(returnDate) : "Not returned")
              << " | Fine: $" << fine 
              << std::endl;
}
