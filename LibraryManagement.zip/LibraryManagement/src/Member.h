#ifndef MEMBER_H
#define MEMBER_H

#include <string>

class Member {
private:
    int id;
    std::string name;
    std::string membershipType;
public:
    Member(int id, const std::string &name, const std::string &membershipType);

    int getId() const;
    std::string getName() const;
    std::string getMembershipType() const;
    void display() const;
};

#endif // MEMBER_H
