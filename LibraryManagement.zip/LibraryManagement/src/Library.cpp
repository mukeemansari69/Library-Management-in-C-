#include "Library.h"
#include <iostream>

Library::Library() : nextBookId(1), nextMemberId(1), nextIssueId(1) {}

void Library::addBook(const std::string &title, const std::string &author,
                      const std::string &category, double cost, const std::string &procurementDate) {
    Book newBook(nextBookId++, title, author, category, cost, procurementDate);
    books.push_back(newBook);
    std::cout << "Book added successfully." << std::endl;
}

void Library::updateBook(int bookId, const std::string &title, const std::string &author,
                         const std::string &category, double cost, const std::string &procurementDate) {
    for (auto &book : books) {
        if (book.getId() == bookId) {
            book = Book(bookId, title, author, category, cost, procurementDate);
            std::cout << "Book updated successfully." << std::endl;
            return;
        }
    }
    std::cout << "Book with ID " << bookId << " not found." << std::endl;
}

void Library::displayBooks() const {
    std::cout << "\n----- Book List -----\n";
    for (const auto &book : books) {
        book.display();
    }
}

Book* Library::findBook(int bookId) {
    for (auto &book : books) {
        if (book.getId() == bookId) {
            return &book;
        }
    }
    return nullptr;
}

void Library::addMember(const std::string &name, const std::string &membershipType) {
    Member newMember(nextMemberId++, name, membershipType);
    members.push_back(newMember);
    std::cout << "Member added successfully." << std::endl;
}

void Library::updateMember(int memberId, const std::string &name, const std::string &membershipType) {
    for (auto &member : members) {
        if (member.getId() == memberId) {
            member = Member(memberId, name, membershipType);
            std::cout << "Member updated successfully." << std::endl;
            return;
        }
    }
    std::cout << "Member with ID " << memberId << " not found." << std::endl;
}

void Library::displayMembers() const {
    std::cout << "\n----- Member List -----\n";
    for (const auto &member : members) {
        member.display();
    }
}

Member* Library::findMember(int memberId) {
    for (auto &member : members) {
        if (member.getId() == memberId) {
            return &member;
        }
    }
    return nullptr;
}

void Library::issueBook(int bookId, int memberId, int issueDate, int dueDate) {
    Book* book = findBook(bookId);
    Member* member = findMember(memberId);
    if (book == nullptr) {
        std::cout << "Book not found." << std::endl;
        return;
    }
    if (member == nullptr) {
        std::cout << "Member not found." << std::endl;
        return;
    }
    if (book->getIsIssued()) {
        std::cout << "Book is already issued." << std::endl;
        return;
    }
    book->setIssued(true);
    Issue newIssue(nextIssueId++, bookId, memberId, issueDate, dueDate);
    issues.push_back(newIssue);
    std::cout << "Book issued successfully." << std::endl;
}

void Library::returnBook(int issueId, int returnDate) {
    for (auto &issue : issues) {
        if (issue.getIssueId() == issueId) {
            if (issue.getReturnDate() != 0) {
                std::cout << "Book already returned." << std::endl;
                return;
            }
            issue.setReturnDate(returnDate);
            issue.calculateFine(returnDate);
            Book* book = findBook(issue.getBookId());
            if (book) {
                book->setIssued(false);
            }
            std::cout << "Book returned successfully." << std::endl;
            return;
        }
    }
    std::cout << "Issue record not found." << std::endl;
}

void Library::displayIssues() const {
    std::cout << "\n----- Issued Books -----\n";
    for (const auto &issue : issues) {
        issue.display();
    }
}

void Library::displayOverdueIssues(int currentDate) const {
    std::cout << "\n----- Overdue Issues -----\n";
    for (const auto &issue : issues) {
        if (issue.getReturnDate() == 0 && currentDate > issue.getDueDate()) {
            Issue temp = issue;
            const_cast<Issue&>(temp).calculateFine(currentDate);
            temp.display();
        }
    }
}
